
// array of global variables
module.exports = {
    // db: 'mongodb://localhost/comp2068-w2017' // local mongodb
    db: 'mongodb://comp2106-books:amanasd0@ds127730.mlab.com:27730/comp2106-books'  // mlab
};
